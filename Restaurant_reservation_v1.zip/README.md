# Restaurant Reservation App

This is a Flutter-based mobile application designed to manage restaurant reservations. The app allows users to make new reservations, view their reservation history, and cancel existing reservations. It supports both Material Design (Android) and Cupertino (iOS) widgets for a platform-adaptive user interface, created using FlutLab.

## Project Structure

- **models/**: Contains data models for the application.
  - `reservation.dart`: Defines the `Reservation` class, which holds details such as name, email, phone, number of guests, date, time, and table assignment.
- **views/**: Houses the main UI screens and navigation logic.
  - `main.dart`: Sets up the `MaterialApp` and defines the `HomeScreen` with a `BottomNavigationBar` for navigation.
  - `reservation_screen.dart`: Implements the `ReservationScreen` for creating new reservations, utilizing the `ReservationForm` widget.
  - `reservation_history_screen.dart`: Displays the `ReservationHistoryScreen` for viewing and canceling past reservations.
- **widgets/**: Includes reusable UI components.
  - `custom_button.dart`: Provides a `CustomButton` widget that adapts to Material or Cupertino styles based on the platform.
  - `reservation_form.dart`: Encapsulates the reservation form UI, including text fields, date/time pickers, and a table selection grid.
- **services/**: Manages business logic and API interactions.
  - `reservation_service.dart`: Contains the `ReservationService` class with a simulated API call for submitting reservations.
- **pubspec.yaml**: Defines project metadata, dependencies (e.g., `intl`, `flutter_staggered_grid_view`), and Flutter configuration.

## Rationale

The project structure is organized to follow a modular and maintainable design pattern, separating concerns for better development and scalability:

- **models/**: Isolating data models like `Reservation` ensures a clear separation between data structure and UI/business logic, making it easier to modify or extend the data schema without affecting other parts of the app.
- **views/**: Centralizing screen definitions and navigation logic in `views/` allows for a focused approach to UI design and user flow management, with `main.dart` serving as the entry point.
- **widgets/**: Placing reusable components like `CustomButton` and `ReservationForm` in `widgets/` promotes code reuse across screens, reducing redundancy and ensuring consistent styling (e.g., platform-adaptive buttons and forms).
- **services/**: Encapsulating business logic and simulated API calls in `services/` keeps the UI layers clean and focused on presentation, while allowing easy integration with real backend services in the future.

This separation of concerns enhances maintainability, supports team collaboration, and aligns with Flutter’s widget-based architecture.

## Features

- **Reservation Creation**: Users can input their details (name, email, phone, guests), select a date, time, and table, and submit a reservation.
- **Reservation History**: Displays a list of existing reservations with options to cancel them.
- **Platform Adaptivity**: Supports both Material Design (Android) and Cupertino (iOS) widgets, adapting the UI based on the device platform.
- **Third-Party Integration**: Uses `flutter_staggered_grid_view` for a responsive table selection grid.

## Dependencies

- `intl: ^0.19.0`: For formatting dates and times.
- `flutter_staggered_grid_view: ^0.7.0`: For creating the staggered grid layout for table selection.

## Getting Started

This project was created using FlutLab[](https://flutlab.io). To run it locally:

1. Ensure you have Flutter installed[](https://flutter.dev/docs/get-started/install).
2. Clone the repository or download the project files.
3. Navigate to the project directory and run `flutter pub get` to install dependencies.
4. Use `flutter run` to launch the app on a connected device or emulator.

For help with Flutter, refer to the official documentation[](https://flutter.dev/docs) or the FlutLab online IDE guide.