package com.example.restaurant_reservation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
