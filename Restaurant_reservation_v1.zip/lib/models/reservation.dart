import 'package:flutter/material.dart';

class Reservation {
  final String name;
  final String email;
  final String phone;
  final int guests;
  final DateTime? date;
  final TimeOfDay? time;
  final String? table;

  Reservation({
    required this.name,
    required this.email,
    required this.phone,
    required this.guests,
    this.date,
    this.time,
    this.table,
  });
}
