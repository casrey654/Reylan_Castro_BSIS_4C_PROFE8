import 'package:restaurant_reservation/models/reservation.dart';

class ReservationService {
  Future<bool> submitReservation(Reservation reservation) async {
    // Simulate API call
    await Future.delayed(Duration(seconds: 1));
    return true;
  }
}
