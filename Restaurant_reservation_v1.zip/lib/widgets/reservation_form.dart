import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:restaurant_reservation/models/reservation.dart';
import 'package:restaurant_reservation/services/reservation_service.dart';
import 'package:restaurant_reservation/widgets/custom_button.dart';
import 'package:restaurant_reservation/views/table_selection_screen.dart';

class ReservationForm extends StatefulWidget {
  final bool useCupertino;

  ReservationForm({this.useCupertino = false});

  @override
  _ReservationFormState createState() => _ReservationFormState();
}

class _ReservationFormState extends State<ReservationForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _guestsController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String? _selectedTable;
  final _reservationService = ReservationService();

  List<String> _tables = [
    'Table 1 (2 seats)',
    'Table 2 (2 seats)',
    'Table 3 (2 seats)',
    'Table 4 (4 seats)',
    'Table 5 (4 seats)',
    'Table 6 (4 seats)',
    'Table 7 (6 seats)',
    'Table 8 (6 seats)',
    'Table 9 (8 seats)',
    'Table 10 (12 seats)',
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _guestsController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    if (widget.useCupertino) {
      showCupertinoModalPopup(
        context: context,
        builder: (context) => Container(
          height: 300,
          color: Colors.white,
          child: CupertinoDatePicker(
            mode: CupertinoDatePickerMode.date,
            initialDateTime: DateTime.now(),
            minimumDate: DateTime.now(),
            maximumDate: DateTime.now().add(Duration(days: 30)),
            onDateTimeChanged: (DateTime newDate) {
              setState(() {
                _selectedDate = newDate;
              });
            },
          ),
        ),
      );
    } else {
      final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime.now().add(Duration(days: 30)),
      );
      if (picked != null && picked != _selectedDate) {
        setState(() {
          _selectedDate = picked;
        });
      }
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    if (widget.useCupertino) {
      showCupertinoModalPopup(
        context: context,
        builder: (context) => Container(
          height: 300,
          color: Colors.white,
          child: CupertinoDatePicker(
            mode: CupertinoDatePickerMode.time,
            initialDateTime: DateTime.now(),
            onDateTimeChanged: (DateTime newDate) {
              setState(() {
                _selectedTime = TimeOfDay.fromDateTime(newDate);
              });
            },
          ),
        ),
      );
    } else {
      final TimeOfDay? picked = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      if (picked != null && picked != _selectedTime) {
        setState(() {
          _selectedTime = picked;
        });
      }
    }
  }

  void _submitReservation() {
    if (_formKey.currentState!.validate()) {
      final reservation = Reservation(
        name: _nameController.text,
        email: _emailController.text,
        phone: _phoneController.text,
        guests: int.parse(_guestsController.text),
        date: _selectedDate,
        time: _selectedTime,
        table: _selectedTable,
      );
      _reservationService.submitReservation(reservation).then((success) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Reservation submitted successfully!'),
              backgroundColor: Colors.green,
            ),
          );
          _formKey.currentState!.reset();
          _nameController.clear();
          _emailController.clear();
          _phoneController.clear();
          _guestsController.clear();
          setState(() {
            _selectedDate = null;
            _selectedTime = null;
            _selectedTable = null;
          });
        }
      });
    }
  }

  void _clearForm() {
    _formKey.currentState?.reset();
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
    _guestsController.clear();
    setState(() {
      _selectedDate = null;
      _selectedTime = null;
      _selectedTable = null;
    });
  }

  void _selectTable(String category) async {
    final selectedTable = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TableSelectionScreen(
          tables: category == 'small'
              ? _tables
                  .where((table) =>
                      int.parse(table.split('(')[1].split(' ')[0]) <= 4)
                  .toList()
              : _tables
                  .where((table) =>
                      int.parse(table.split('(')[1].split(' ')[0]) >= 6)
                  .toList(),
          category: category,
        ),
      ),
    );
    if (selectedTable != null) {
      setState(() {
        _selectedTable = selectedTable;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            widget.useCupertino
                ? CupertinoTextField(
                    controller: _nameController,
                    placeholder: 'Full Name',
                    padding: EdgeInsets.all(12),
                  )
                : TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: 'Full Name',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your name';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 16),
            widget.useCupertino
                ? CupertinoTextField(
                    controller: _emailController,
                    placeholder: 'Email',
                    padding: EdgeInsets.all(12),
                  )
                : TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      }
                      if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          .hasMatch(value)) {
                        return 'Please enter a valid email';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 16),
            widget.useCupertino
                ? CupertinoTextField(
                    controller: _phoneController,
                    placeholder: 'Phone Number',
                    padding: EdgeInsets.all(12),
                  )
                : TextFormField(
                    controller: _phoneController,
                    decoration: InputDecoration(
                      labelText: 'Phone Number',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your phone number';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 16),
            widget.useCupertino
                ? CupertinoTextField(
                    controller: _guestsController,
                    placeholder: 'Number of Guests',
                    padding: EdgeInsets.all(12),
                    keyboardType: TextInputType.number,
                  )
                : TextFormField(
                    controller: _guestsController,
                    decoration: InputDecoration(
                      labelText: 'Number of Guests',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter number of guests';
                      }
                      final n = int.tryParse(value);
                      if (n == null || n <= 0) {
                        return 'Please enter a valid number';
                      }
                      return null;
                    },
                  ),
            SizedBox(height: 16),
            ListTile(
              title: Text(
                  'Date: ${_selectedDate == null ? 'Not selected' : DateFormat('yyyy-MM-dd').format(_selectedDate!)}'),
              trailing: Icon(widget.useCupertino
                  ? CupertinoIcons.calendar
                  : Icons.calendar_today),
              onTap: () => _selectDate(context),
            ),
            if (_selectedDate == null)
              Text('Please select a date', style: TextStyle(color: Colors.red)),
            SizedBox(height: 16),
            ListTile(
              title: Text(
                  'Time: ${_selectedTime == null ? 'Not selected' : _selectedTime!.format(context)}'),
              trailing: Icon(widget.useCupertino
                  ? CupertinoIcons.time
                  : Icons.access_time),
              onTap: () => _selectTime(context),
            ),
            if (_selectedTime == null)
              Text('Please select a time', style: TextStyle(color: Colors.red)),
            SizedBox(height: 16),
            Text('Select Table:', style: TextStyle(fontSize: 16)),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _selectTable('small'),
                    child: Container(
                      height: 100,
                      color: Colors.blue[100],
                      child: Center(child: Text('Small Tables (2-4 seats)')),
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _selectTable('large'),
                    child: Container(
                      height: 100,
                      color: Colors.blue[200],
                      child: Center(child: Text('Large Tables (6-12 seats)')),
                    ),
                  ),
                ),
              ],
            ),
            // Display selected table below
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                _selectedTable == null
                    ? 'No table selected'
                    : 'Selected Table: $_selectedTable',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            if (_selectedTable == null)
              Text('Please select a table',
                  style: TextStyle(color: Colors.red)),
            SizedBox(height: 24),
            Container(
              height: 150,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomButton(
                      text: 'Clear Form',
                      onPressed: _clearForm,
                      useCupertino: widget.useCupertino,
                    ),
                    SizedBox(height: 16),
                    CustomButton(
                      text: 'Make Reservation',
                      onPressed: _submitReservation,
                      useCupertino: widget.useCupertino,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
