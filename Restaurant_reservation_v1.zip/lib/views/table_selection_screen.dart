import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:restaurant_reservation/widgets/custom_button.dart';

class TableSelectionScreen extends StatefulWidget {
  final List<String> tables;
  final String category;

  TableSelectionScreen({required this.tables, required this.category});

  @override
  _TableSelectionScreenState createState() => _TableSelectionScreenState();
}

class _TableSelectionScreenState extends State<TableSelectionScreen> {
  String? _selectedTable;

  @override
  Widget build(BuildContext context) {
    final bool isIOS = Theme.of(context).platform == TargetPlatform.iOS;
    return isIOS
        ? CupertinoPageScaffold(
            navigationBar: CupertinoNavigationBar(
              middle: Text(
                  '${widget.category == 'small' ? 'Small' : 'Large'} Tables'),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: widget.tables.length,
                        itemBuilder: (context, index) {
                          final table = widget.tables[index];
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                _selectedTable = table;
                              });
                            },
                            child: Card(
                              color: _selectedTable == table
                                  ? Colors.blue[100]
                                  : null,
                              child: ListTile(
                                title: Text(table),
                                trailing: _selectedTable == table
                                    ? Icon(Icons.check, color: Colors.green)
                                    : null,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    CustomButton(
                      text: 'Select Table',
                      onPressed: () {
                        if (_selectedTable != null) {
                          Navigator.pop(context, _selectedTable);
                        }
                      },
                      useCupertino: isIOS,
                    ),
                  ],
                ),
              ),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              title: Text(
                  '${widget.category == 'small' ? 'Small' : 'Large'} Tables'),
            ),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      itemCount: widget.tables.length,
                      itemBuilder: (context, index) {
                        final table = widget.tables[index];
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedTable = table;
                            });
                          },
                          child: Card(
                            color: _selectedTable == table
                                ? Colors.blue[100]
                                : null,
                            child: ListTile(
                              title: Text(table),
                              trailing: _selectedTable == table
                                  ? Icon(Icons.check, color: Colors.green)
                                  : null,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  CustomButton(
                    text: 'Select Table',
                    onPressed: () {
                      if (_selectedTable != null) {
                        Navigator.pop(context, _selectedTable);
                      }
                    },
                    useCupertino: isIOS,
                  ),
                ],
              ),
            ),
          );
  }
}
