import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:restaurant_reservation/models/reservation.dart';
import 'package:restaurant_reservation/widgets/custom_button.dart';

class ReservationHistoryScreen extends StatefulWidget {
  @override
  _ReservationHistoryScreenState createState() =>
      _ReservationHistoryScreenState();
}

class _ReservationHistoryScreenState extends State<ReservationHistoryScreen> {
  List<Reservation> _reservations = [
    Reservation(
      name: "John Doe",
      email: "john@example.com",
      phone: "123-456-7890",
      guests: 4,
      date: DateTime.now().add(Duration(days: 1)),
      time: TimeOfDay(hour: 19, minute: 0),
      table: "Table 1 (2 seats)",
    ),
    Reservation(
      name: "Jane Smith",
      email: "jane@example.com",
      phone: "987-654-3210",
      guests: 2,
      date: DateTime.now().add(Duration(days: 2)),
      time: TimeOfDay(hour: 18, minute: 30),
      table: "Table 4 (4 seats)",
    ),
  ];

  void _cancelReservation(int index) {
    setState(() {
      _reservations.removeAt(index);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          // Instruction 9: Chat bubble UI for SnackBar
          content: Container(
            padding: EdgeInsets.all(12),
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.blue[50],
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text('Reservation canceled successfully!',
                style: TextStyle(fontSize: 16)),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          behavior: SnackBarBehavior.floating,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool isIOS = Theme.of(context).platform == TargetPlatform.iOS;
    return isIOS
        ? CupertinoPageScaffold(
            navigationBar: CupertinoNavigationBar(
              middle: Text('Reservation History'),
            ),
            child: SafeArea(
              child: _reservations.isEmpty
                  ? Center(
                      // Instruction 3: Container with padding, margin, background color
                      child: Container(
                        padding: EdgeInsets.all(16),
                        margin:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.blue[100],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text('No reservations found',
                            style: TextStyle(fontSize: 18)),
                      ),
                    )
                  : Column(
                      // Instruction 8: Flexible in Column
                      children: [
                        Flexible(
                          flex: 1,
                          child: ListView.builder(
                            itemCount: _reservations.length,
                            itemBuilder: (context, index) {
                              final reservation = _reservations[index];
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16.0, vertical: 8.0),
                                child: Card(
                                  child: ListTile(
                                    title: Text(
                                        'Reservation for ${reservation.name}'),
                                    subtitle: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                            'Date: ${DateFormat('yyyy-MM-dd').format(reservation.date!)}'),
                                        Text(
                                            'Time: ${reservation.time!.format(context)}'),
                                        Text('Table: ${reservation.table}'),
                                        Text('Guests: ${reservation.guests}'),
                                        Text('Email: ${reservation.email}'),
                                        Text('Phone: ${reservation.phone}'),
                                      ],
                                    ),
                                    trailing: CustomButton(
                                      text: 'Cancel',
                                      onPressed: () =>
                                          _cancelReservation(index),
                                      useCupertino: isIOS,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              title: Text('Reservation History'),
            ),
            body: _reservations.isEmpty
                ? Center(
                    // Instruction 3: Container with padding, margin, background color
                    child: Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('No reservations found',
                          style: TextStyle(fontSize: 18)),
                    ),
                  )
                : Column(
                    // Instruction 8: Flexible in Column
                    children: [
                      Flexible(
                        flex: 1,
                        child: ListView.builder(
                          itemCount: _reservations.length,
                          itemBuilder: (context, index) {
                            final reservation = _reservations[index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 8.0),
                              child: Card(
                                child: ListTile(
                                  title: Text(
                                      'Reservation for ${reservation.name}'),
                                  subtitle: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                          'Date: ${DateFormat('yyyy-MM-dd').format(reservation.date!)}'),
                                      Text(
                                          'Time: ${reservation.time!.format(context)}'),
                                      Text('Table: ${reservation.table}'),
                                      Text('Guests: ${reservation.guests}'),
                                      Text('Email: ${reservation.email}'),
                                      Text('Phone: ${reservation.phone}'),
                                    ],
                                  ),
                                  trailing: CustomButton(
                                    text: 'Cancel',
                                    onPressed: () => _cancelReservation(index),
                                    useCupertino: isIOS,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
          );
  }
}
