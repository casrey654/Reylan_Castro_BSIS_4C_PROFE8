import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:restaurant_reservation/widgets/reservation_form.dart';

class ReservationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final bool isIOS = Theme.of(context).platform == TargetPlatform.iOS;
    return isIOS
        ? CupertinoPageScaffold(
            navigationBar: CupertinoNavigationBar(
              middle:
                  SizedBox.shrink(), // Remove "Restaurant Reservation" title
            ),
            child: SafeArea(
              child: Stack(
                children: [
                  Container(
                    color: Colors.blue[50], // Solid background color
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text('Pending',
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black)),
                            Text('Confirmed',
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black)),
                            Text('Canceled',
                                style: TextStyle(
                                    fontSize: 16, color: Colors.black)),
                          ],
                        ),
                        SizedBox(height: 16),
                        Expanded(child: ReservationForm(useCupertino: true)),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 16,
                    right: 16,
                    child: FloatingActionButton(
                      onPressed: () {},
                      child: Icon(Icons.book),
                    ),
                  ),
                ],
              ),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              title: SizedBox.shrink(), // Remove "Restaurant Reservation" title
            ),
            body: Stack(
              children: [
                Container(
                  color: Colors.blue[50], // Solid background color
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text('Pending',
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black)),
                          Text('Confirmed',
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black)),
                          Text('Canceled',
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black)),
                        ],
                      ),
                      SizedBox(height: 16),
                      Expanded(child: ReservationForm(useCupertino: false)),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 16,
                  right: 16,
                  child: FloatingActionButton(
                    onPressed: () {},
                    child: Icon(Icons.book),
                  ),
                ),
              ],
            ),
          );
  }
}
