import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'register_screen.dart';
import 'main_screen.dart';

void main() {
  runApp(LanguageTutoringApp());
}

class LanguageTutoringApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Language Tutoring Service',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MainScreen(),
      routes: {
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
      },
    );
  }
}
