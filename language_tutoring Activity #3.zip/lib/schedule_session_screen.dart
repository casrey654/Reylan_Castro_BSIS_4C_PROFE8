import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ScheduleSessionScreen extends StatefulWidget {
  @override
  _ScheduleSessionScreenState createState() => _ScheduleSessionScreenState();
}

class _ScheduleSessionScreenState extends State<ScheduleSessionScreen> {
  final _sessionFormKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _sessionNotesController = TextEditingController();
  String _displayedText = '';
  String? _selectedRole = 'Student';
  bool _isNativeSpeaker = false;
  bool _receiveNotifications = false;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  List<Map<String, dynamic>> _submittedSessions = [];

  @override
  void dispose() {
    _usernameController.dispose();
    _sessionNotesController.dispose();
    super.dispose();
  }

  void _submitSession() {
    if (_sessionFormKey.currentState!.validate()) {
      // Simulate payment confirmation
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Confirm Payment'),
          content: Text('Proceed with payment for this tutoring session?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() {
                  _submittedSessions.add({
                    'username': _usernameController.text,
                    'role': _selectedRole,
                    'nativeSpeaker': _isNativeSpeaker,
                    'notifications': _receiveNotifications,
                    'date': _selectedDate != null
                        ? DateFormat('yyyy-MM-dd').format(_selectedDate!)
                        : 'Not selected',
                    'time': _selectedTime != null
                        ? _selectedTime!.format(context)
                        : 'Not selected',
                    'notes': _sessionNotesController.text,
                    'paymentStatus': 'Paid', // Simulated payment status
                  });
                  _displayedText = _sessionNotesController.text;
                  _usernameController.clear();
                  _sessionNotesController.clear();
                  _selectedRole = 'Student';
                  _isNativeSpeaker = false;
                  _receiveNotifications = false;
                  _selectedDate = null;
                  _selectedTime = null;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content:
                          Text('Session Scheduled and Payment Confirmed!')),
                );
              },
              child: Text('Confirm'),
            ),
          ],
        ),
      );
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2025),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Schedule a Tutoring Session')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Form(
              key: _sessionFormKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Session Details',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  TextFormField(
                    controller: _usernameController,
                    decoration: InputDecoration(labelText: 'Username'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a username';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _sessionNotesController,
                    decoration: InputDecoration(
                        labelText: 'Session Notes (e.g., Language to Learn)'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter session notes';
                      }
                      return null;
                    },
                  ),
                  DropdownButtonFormField<String>(
                    value: _selectedRole,
                    decoration: InputDecoration(labelText: 'Role'),
                    items: ['Student', 'Tutor'].map((String role) {
                      return DropdownMenuItem<String>(
                        value: role,
                        child: Text(role),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedRole = value;
                      });
                    },
                  ),
                  CheckboxListTile(
                    title: Text('I am a native speaker'),
                    value: _isNativeSpeaker,
                    onChanged: (value) {
                      setState(() {
                        _isNativeSpeaker = value!;
                      });
                    },
                  ),
                  SwitchListTile(
                    title: Text('Receive session notifications'),
                    value: _receiveNotifications,
                    onChanged: (value) {
                      setState(() {
                        _receiveNotifications = value;
                      });
                    },
                  ),
                  ListTile(
                    title: Text(_selectedDate == null
                        ? 'Select Session Date'
                        : 'Date: ${DateFormat('yyyy-MM-dd').format(_selectedDate!)}'),
                    trailing: Icon(Icons.calendar_today),
                    onTap: () => _selectDate(context),
                  ),
                  ListTile(
                    title: Text(_selectedTime == null
                        ? 'Select Session Time'
                        : 'Time: ${_selectedTime!.format(context)}'),
                    trailing: Icon(Icons.access_time),
                    onTap: () => _selectTime(context),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitSession,
                    child: Text('Schedule and Pay'),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text('Last Session Notes: $_displayedText',
                style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            Text('Scheduled Sessions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            _submittedSessions.isEmpty
                ? Text('No sessions scheduled yet.')
                : ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: _submittedSessions.length,
                    itemBuilder: (context, index) {
                      final session = _submittedSessions[index];
                      return Card(
                        child: ListTile(
                          title: Text('Username: ${session['username']}'),
                          subtitle: Text(
                            'Role: ${session['role']}\n'
                            'Native Speaker: ${session['nativeSpeaker'] ? 'Yes' : 'No'}\n'
                            'Notifications: ${session['notifications'] ? 'Yes' : 'No'}\n'
                            'Date: ${session['date']}\n'
                            'Time: ${session['time']}\n'
                            'Notes: ${session['notes']}\n'
                            'Payment: ${session['paymentStatus']}',
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }
}
