import 'package:flutter/material.dart';
import 'session_management_screens.dart';
import 'profile_and_learning_hub.dart';
import 'cart_screen.dart';
import 'todo_screen.dart';

class MainScreen extends StatefulWidget {
  final int initialIndex;
  MainScreen({this.initialIndex = 0});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late int _selectedIndex;
  final List<Widget> _screens = [
    HomeScreen(),
    ScheduleSessionScreen(),
    DocumentTrackerScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Language Tutoring Service',
              style: TextStyle(fontFamily: 'Calibri'))),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'Language Tutoring Menu',
                style: TextStyle(
                    color: Colors.white, fontSize: 24, fontFamily: 'Calibri'),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home', style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedIndex = 0;
                });
              },
            ),
            ListTile(
              leading: Icon(Icons.info),
              title: Text('About', style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => AboutScreen()));
              },
            ),
            ListTile(
              leading: Icon(Icons.contact_mail),
              title: Text('Contact', style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ContactScreen()));
              },
            ),
            ListTile(
              leading: Icon(Icons.book),
              title:
                  Text('Learning Hub', style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/tabs');
              },
            ),
            ListTile(
              leading: Icon(Icons.shopping_cart),
              title: Text('Resource Cart',
                  style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/cart');
              },
            ),
            ListTile(
              leading: Icon(Icons.list),
              title: Text('Learning Tasks',
                  style: TextStyle(fontFamily: 'Calibri')),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/todo');
              },
            ),
          ],
        ),
      ),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.schedule), label: 'Schedule'),
          BottomNavigationBarItem(
              icon: Icon(Icons.description), label: 'Documents'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8',
              height: 200,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Text(
                  'Failed to load image',
                  style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 20),
            Text(
              'Welcome to Language Tutoring',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
              child: Text('Login', style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/register'),
              child: Text('Register', style: TextStyle(fontFamily: 'Calibri')),
            ),
          ],
        ),
      ),
    );
  }
}

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text('About', style: TextStyle(fontFamily: 'Calibri'))),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'About Language Tutoring',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            Text(
              'Our platform connects language learners with expert tutors to enhance their language skills through personalized sessions. Whether you are a student or a tutor, our app provides tools for scheduling, document tracking, and profile management.',
              style: TextStyle(fontSize: 16, fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Back', style: TextStyle(fontFamily: 'Calibri')),
            ),
          ],
        ),
      ),
    );
  }
}

class ContactScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Contact', style: TextStyle(fontFamily: 'Calibri'))),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Contact Us',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            Text(
              'Have questions? Reach out to us!\n\nEmail: support@languagetutoring.com\nPhone: +1 (555) 123-4567\nAddress: 123 Language Lane, Education City',
              style: TextStyle(fontSize: 16, fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Back', style: TextStyle(fontFamily: 'Calibri')),
            ),
          ],
        ),
      ),
    );
  }
}
