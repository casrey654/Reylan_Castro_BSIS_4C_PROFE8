import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:audioplayers/audioplayers.dart';
import 'main_screen.dart';
import 'theme_provider.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String? _name = 'Not set';
  String? _email = 'Not set';
  String? _role = 'Not set';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _name = prefs.getString('user_name') ?? 'Not set';
      _email = prefs.getString('user_email') ?? 'Not set';
      _role = prefs.getString('user_role') ?? 'Not set';
    });
  }

  Future<void> _clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    setState(() {
      _name = 'Not set';
      _email = 'Not set';
      _role = 'Not set';
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return Scaffold(
      appBar: AppBar(
          title: Text('Profile', style: TextStyle(fontFamily: 'Calibri'))),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'User Profile',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            Card(
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.blue, width: 2),
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/profile.png',
                          width: 80,
                          height: 80,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Name: $_name',
                          style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'Calibri',
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'Email: $_email',
                          style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'Calibri',
                              fontStyle: FontStyle.italic),
                        ),
                        Text(
                          'Role: $_role',
                          style: TextStyle(fontSize: 16, fontFamily: 'Calibri'),
                        ),
                        Icon(Icons.language, color: Colors.blue, size: 30),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            SwitchListTile(
              title: Text('Dark Mode', style: TextStyle(fontFamily: 'Calibri')),
              value: themeProvider.isDarkMode,
              onChanged: (value) {
                themeProvider.toggleTheme();
              },
            ),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Profile Update Not Implemented')),
                );
              },
              child: Text('Update Profile',
                  style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                _clearUserData();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => MainScreen(initialIndex: 0)),
                );
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Logged Out')),
                );
              },
              child: Text('Logout', style: TextStyle(fontFamily: 'Calibri')),
            ),
          ],
        ),
      ),
    );
  }
}

class TabScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Learning Hub', style: TextStyle(fontFamily: 'Calibri')),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Lessons', icon: Icon(Icons.book)),
              Tab(text: 'Quizzes', icon: Icon(Icons.quiz)),
              Tab(text: 'Resources', icon: Icon(Icons.library_books)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Center(
              child: Text(
                'Browse language lessons tailored to your level.',
                style: TextStyle(fontSize: 18, fontFamily: 'Calibri'),
              ),
            ),
            Center(
              child: Text(
                'Test your skills with interactive quizzes.',
                style: TextStyle(fontSize: 18, fontFamily: 'Calibri'),
              ),
            ),
            ResourcesTab(),
          ],
        ),
      ),
    );
  }
}

class ResourcesTab extends StatefulWidget {
  @override
  _ResourcesTabState createState() => _ResourcesTabState();
}

class _ResourcesTabState extends State<ResourcesTab> {
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isAudioPlaying = false;
  int _currentImageIndex = 0;
  final List<String> _images = [
    'assets/images/germanlng.png',
    'assets/images/japanlng.png',
    'assets/images/koreanlng.png',
  ];

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset('assets/videos/tutorial.mp4')
      ..initialize().then((_) {
        setState(() {
          _chewieController = ChewieController(
            videoPlayerController: _videoController,
            autoPlay: false,
            looping: false,
          );
        });
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _chewieController?.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _playAudio() async {
    if (_isAudioPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.play(AssetSource('audio/pronunciation.mp3'));
    }
    setState(() {
      _isAudioPlaying = !_isAudioPlaying;
    });
  }

  void _stopAudio() async {
    await _audioPlayer.stop();
    setState(() {
      _isAudioPlaying = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Image Gallery',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Calibri'),
          ),
          SizedBox(height: 10),
          Container(
            height: 200,
            child: Stack(
              children: [
                PageView.builder(
                  itemCount: _images.length,
                  onPageChanged: (index) {
                    setState(() {
                      _currentImageIndex = index;
                    });
                  },
                  itemBuilder: (context, index) {
                    return Image.asset(
                      _images[index],
                      fit: BoxFit.cover,
                    );
                  },
                ),
                Positioned(
                  bottom: 10,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _images.length,
                      (index) => Container(
                        margin: EdgeInsets.symmetric(horizontal: 4),
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _currentImageIndex == index
                              ? Colors.blue
                              : Colors.grey,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Tutorial Video',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Calibri'),
          ),
          SizedBox(height: 10),
          _chewieController != null
              ? AspectRatio(
                  aspectRatio: _videoController.value.aspectRatio,
                  child: Chewie(controller: _chewieController!),
                )
              : Center(child: CircularProgressIndicator()),
          SizedBox(height: 20),
          Text(
            'Pronunciation Audio',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Calibri'),
          ),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: _playAudio,
                child: Text(_isAudioPlaying ? 'Pause' : 'Play',
                    style: TextStyle(fontFamily: 'Calibri')),
              ),
              SizedBox(width: 10),
              ElevatedButton(
                onPressed: _stopAudio,
                child: Text('Stop', style: TextStyle(fontFamily: 'Calibri')),
              ),
            ],
          ),
          SizedBox(height: 20),
          Text(
            'Resource Grid',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Calibri'),
          ),
          SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: _images.length,
            itemBuilder: (context, index) {
              return Image.asset(
                _images[index],
                fit: BoxFit.cover,
              );
            },
          ),
        ],
      ),
    );
  }
}
