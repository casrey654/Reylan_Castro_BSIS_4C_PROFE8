import 'package:flutter/material.dart';

class CartItem {
  final String id;
  final String title;
  final double price;

  CartItem({required this.id, required this.title, required this.price});
}

class CartProvider with ChangeNotifier {
  List<CartItem> _items = [];

  List<CartItem> get items => _items;

  void addItem(String id, String title, double price) {
    _items.add(CartItem(id: id, title: title, price: price));
    notifyListeners();
  }

  void removeItem(String id) {
    _items.removeWhere((item) => item.id == id);
    notifyListeners();
  }

  double get totalPrice => _items.fold(0, (sum, item) => sum + item.price);

  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}
