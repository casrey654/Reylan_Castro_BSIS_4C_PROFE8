import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      appBar: AppBar(
          title:
              Text('Resource Cart', style: TextStyle(fontFamily: 'Calibri'))),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Cart',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 20),
            cart.items.isEmpty
                ? Text('No resources in cart.',
                    style: TextStyle(fontFamily: 'Calibri'))
                : Expanded(
                    child: ListView.builder(
                      itemCount: cart.items.length,
                      itemBuilder: (context, index) {
                        final item = cart.items[index];
                        return ListTile(
                          title: Text(item.title,
                              style: TextStyle(fontFamily: 'Calibri')),
                          subtitle: Text('\$${item.price.toStringAsFixed(2)}',
                              style: TextStyle(fontFamily: 'Calibri')),
                          trailing: IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              context.read<CartProvider>().removeItem(item.id);
                            },
                          ),
                        );
                      },
                    ),
                  ),
            SizedBox(height: 20),
            Text(
              'Total: \$${cart.totalPrice.toStringAsFixed(2)}',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                context.read<CartProvider>().clearCart();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('Cart Cleared!',
                          style: TextStyle(fontFamily: 'Calibri'))),
                );
              },
              child:
                  Text('Clear Cart', style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                context.read<CartProvider>().addItem(
                      DateTime.now().toString(),
                      'Spanish Lesson Pack',
                      19.99,
                    );
              },
              child: Text('Add Sample Resource',
                  style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 20),
            Text(
              'Note: context.watch() updates the UI when cart changes, while context.read() is used for actions like adding/removing items without rebuilding.',
              style: TextStyle(
                  fontSize: 14,
                  fontStyle: FontStyle.italic,
                  fontFamily: 'Calibri'),
            ),
          ],
        ),
      ),
    );
  }
}
