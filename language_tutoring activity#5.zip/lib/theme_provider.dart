import 'package:flutter/material.dart';

class ThemeProvider with ChangeNotifier {
  ThemeData _themeData = ThemeData.light();

  ThemeData get themeData => _themeData;

  bool get isDarkMode => _themeData.brightness == Brightness.dark;

  void toggleTheme() {
    _themeData = _themeData.brightness == Brightness.light
        ? ThemeData.dark().copyWith(
            primaryColor: Colors.blue,
            scaffoldBackgroundColor: Colors.grey[900],
            textTheme: TextTheme(
              titleLarge: TextStyle(fontFamily: 'Calibri', color: Colors.white),
              bodyMedium:
                  TextStyle(fontFamily: 'Calibri', color: Colors.white70),
            ),
          )
        : ThemeData.light().copyWith(
            primaryColor: Colors.blue,
            scaffoldBackgroundColor: Colors.white,
            textTheme: TextTheme(
              titleLarge: TextStyle(fontFamily: 'Calibri', color: Colors.black),
              bodyMedium:
                  TextStyle(fontFamily: 'Calibri', color: Colors.black87),
            ),
          );
    notifyListeners();
  }
}
