import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth_screens.dart';
import 'main_screen.dart';
import 'profile_and_learning_hub.dart';
import 'cart_provider.dart';
import 'theme_provider.dart';
import 'todo_provider.dart';
import 'cart_screen.dart';
import 'todo_screen.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => TodoProvider()),
      ],
      child: LanguageTutoringApp(),
    ),
  );
}

class LanguageTutoringApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Language Tutoring Service',
      theme: Provider.of<ThemeProvider>(context).themeData,
      initialRoute: '/',
      routes: {
        '/': (context) => MainScreen(),
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/tabs': (context) => TabScreen(),
        '/cart': (context) => CartScreen(),
        '/todo': (context) => TodoScreen(),
      },
    );
  }
}
