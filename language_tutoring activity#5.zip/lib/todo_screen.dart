import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'todo_provider.dart';

class TodoScreen extends StatelessWidget {
  final _todoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final todoProvider = context.watch<TodoProvider>();
    return Scaffold(
      appBar: AppBar(
          title: Text('Language Learning Tasks',
              style: TextStyle(fontFamily: 'Calibri'))),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Add Task',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _todoController,
              decoration: InputDecoration(
                labelText: 'Task (e.g., Practice Spanish Verbs)',
                labelStyle: TextStyle(fontFamily: 'Calibri'),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                if (_todoController.text.isNotEmpty) {
                  context.read<TodoProvider>().addTodo(_todoController.text);
                  _todoController.clear();
                }
              },
              child: Text('Add Task', style: TextStyle(fontFamily: 'Calibri')),
            ),
            SizedBox(height: 20),
            Text(
              'Tasks',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Calibri'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: todoProvider.todos.length,
                itemBuilder: (context, index) {
                  final todo = todoProvider.todos[index];
                  return ListTile(
                    leading: Icon(
                      todo.isCompleted
                          ? Icons.check_circle
                          : Icons.circle_outlined,
                      color: todo.isCompleted ? Colors.green : Colors.grey,
                      size: 30,
                    ),
                    title: Text(
                      todo.title,
                      style: TextStyle(
                        fontFamily: 'Calibri',
                        decoration: todo.isCompleted
                            ? TextDecoration.lineThrough
                            : null,
                      ),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () =>
                          context.read<TodoProvider>().removeTodo(todo.id),
                    ),
                    onTap: () =>
                        context.read<TodoProvider>().toggleTodo(todo.id),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
