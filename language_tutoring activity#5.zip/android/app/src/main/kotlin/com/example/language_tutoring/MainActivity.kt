package com.example.language_tutoring

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
