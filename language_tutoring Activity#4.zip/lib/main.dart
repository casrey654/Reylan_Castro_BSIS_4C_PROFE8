import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'register_screen.dart';
import 'main_screen.dart';
import 'about_screen.dart';
import 'contact_screen.dart';
import 'tab_screen.dart';

void main() {
  runApp(LanguageTutoringApp());
}

class LanguageTutoringApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Language Tutoring Service',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => MainScreen(),
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/about': (context) => AboutScreen(),
        '/contact': (context) => ContactScreen(),
        '/tabs': (context) => TabScreen(),
      },
    );
  }
}
