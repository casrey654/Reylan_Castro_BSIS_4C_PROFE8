import 'package:flutter/material.dart';

class TabScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Learning Hub'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Lessons', icon: Icon(Icons.book)),
              Tab(text: 'Quizzes', icon: Icon(Icons.quiz)),
              Tab(text: 'Resources', icon: Icon(Icons.library_books)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Center(
              child: Text(
                'Browse language lessons tailored to your level.',
                style: TextStyle(fontSize: 18),
              ),
            ),
            Center(
              child: Text(
                'Test your skills with interactive quizzes.',
                style: TextStyle(fontSize: 18),
              ),
            ),
            Center(
              child: Text(
                'Access additional learning materials and resources.',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
