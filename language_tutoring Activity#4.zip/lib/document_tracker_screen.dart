import 'package:flutter/material.dart';

class DocumentTrackerScreen extends StatefulWidget {
  @override
  _DocumentTrackerScreenState createState() => _DocumentTrackerScreenState();
}

class _DocumentTrackerScreenState extends State<DocumentTrackerScreen> {
  final _documentController = TextEditingController();
  final _documentFormKey = GlobalKey<FormState>();
  List<Map<String, String>> _documents = [];

  @override
  void dispose() {
    _documentController.dispose();
    super.dispose();
  }

  void _addDocument() {
    if (_documentFormKey.currentState!.validate()) {
      setState(() {
        _documents.add({
          'title': _documentController.text,
          'date': DateTime.now().toString().substring(0, 10),
        });
        _documentController.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Document Added!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Document Tracker')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Add Tutoring Materials',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Form(
              key: _documentFormKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _documentController,
                    decoration: InputDecoration(
                        labelText: 'Document Title (e.g., Lesson Plan)'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a document title';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: _addDocument,
                    child: Text('Add Document'),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text('Available Documents',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            _documents.isEmpty
                ? Text('No documents added yet.')
                : Expanded(
                    child: ListView.builder(
                      itemCount: _documents.length,
                      itemBuilder: (context, index) {
                        final doc = _documents[index];
                        return Card(
                          child: ListTile(
                            title: Text(doc['title']!),
                            subtitle: Text('Added on: ${doc['date']}'),
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
