import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main_screen.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String? _name = 'Not set';
  String? _email = 'Not set';
  String? _role = 'Not set';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _name = prefs.getString('user_name') ?? 'Not set';
      _email = prefs.getString('user_email') ?? 'Not set';
      _role = prefs.getString('user_role') ?? 'Not set';
    });
  }

  Future<void> _clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    setState(() {
      _name = 'Not set';
      _email = 'Not set';
      _role = 'Not set';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profile')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('User Profile',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            Text('Name: $_name', style: TextStyle(fontSize: 16)),
            Text('Email: $_email', style: TextStyle(fontSize: 16)),
            Text('Role: $_role', style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Profile Update Not Implemented')),
                );
              },
              child: Text('Update Profile'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                _clearUserData();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => MainScreen(initialIndex: 0)),
                );
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Logged Out')),
                );
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
